# CV Parsing & Skills Classification Module (NLP)

Parses CVs (PDF / DOCX / TXT, mixed **French & English**) and produces structured JSON:
contact info, detected sections, per-section language, normalized skills classified
into predefined categories, and date ranges.

## Install

```bash
pip install pdfplumber python-docx rapidfuzz langdetect
```

## Usage

```bash
# Parse one or more CVs -> structured JSON
python -m cv_parser.pipeline samples/cv_fr_en_mixed.txt

# Evaluate against a gold-annotated test set (precision / recall / F1)
python -m cv_parser.evaluate samples/gold.json
```

From Python:

```python
from cv_parser.pipeline import parse_cv
result = parse_cv("my_cv.pdf")
print(result["skills_by_category"])
```

## How it works (pipeline)

1. **Extraction** (`extract.py`) — text from PDF (pdfplumber), DOCX (python-docx,
   incl. tables), or TXT.
2. **Section segmentation** (`sections.py`) — bilingual FR/EN header detection
   ("Compétences" / "Skills", "Formation" / "Education", ...), longest-match-first.
3. **Entities** (`entities.py`) — regex extraction of emails, phones,
   LinkedIn/GitHub, bilingual date ranges ("Juin 2025 - Août 2025",
   "Jan 2023 - present"); per-section language detection (langdetect);
   heuristic name detection.
4. **Skills** (`skills.py`) — two-pass matching against `data/skills_db.json`,
   a bilingual alias database (~130 skills, 7 categories):
   - exact word-boundary matching on aliases (handles "c++", "c#");
   - fuzzy matching (RapidFuzz, ratio >= 90) on 1–3 word n-grams for
     typos/variants.
   Each match is **normalized** to a canonical skill name and **classified**
   into its predefined category. FR and EN aliases map to the same canonical
   skill ("gestion de projet" = "project management").
5. **Evaluation** (`evaluate.py`) — precision / recall / F1 overall and per file,
   with lists of false positives and missed skills to guide improvement.

## Extending

- **Add skills/categories**: edit `data/skills_db.json` — no code changes needed.
- **Improve precision**: tune `FUZZY_THRESHOLD` in `skills.py`; inspect the
  `false_positives` / `missed` lists in evaluation output.
- **ML upgrade path** (future work section for the report): replace/augment the
  dictionary with a multilingual NER model (XLM-RoBERTa) and embedding-based
  matching to the ESCO taxonomy (sentence-transformers).

## Project layout

```
cv_parser/
├── cv_parser/
│   ├── extract.py     # PDF/DOCX/TXT -> raw text
│   ├── sections.py    # bilingual section splitting
│   ├── entities.py    # contact, dates, language detection
│   ├── skills.py      # matching + classification
│   ├── pipeline.py    # end-to-end + CLI
│   └── evaluate.py    # P/R/F1 evaluation
├── data/skills_db.json
└── samples/           # sample CV + gold annotations
```

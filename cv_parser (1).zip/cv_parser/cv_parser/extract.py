"""Text extraction from CV files (PDF, DOCX, TXT)."""
from pathlib import Path


def extract_text(path: str) -> str:
    """Extract raw text from a CV file. Dispatches on extension."""
    p = Path(path)
    ext = p.suffix.lower()
    if ext == ".pdf":
        return _from_pdf(p)
    if ext == ".docx":
        return _from_docx(p)
    if ext in (".txt", ".md"):
        return p.read_text(encoding="utf-8", errors="replace")
    raise ValueError(f"Unsupported file type: {ext}")


def _from_pdf(p: Path) -> str:
    import pdfplumber
    pages = []
    with pdfplumber.open(p) as pdf:
        for page in pdf.pages:
            txt = page.extract_text() or ""
            pages.append(txt)
    return "\n".join(pages)


def _from_docx(p: Path) -> str:
    import docx
    doc = docx.Document(str(p))
    parts = [para.text for para in doc.paragraphs]
    # also grab text inside tables (common in CV layouts)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                if cell.text.strip():
                    parts.append(cell.text)
    return "\n".join(parts)

"""End-to-end CV parsing pipeline.

Usage:
    python -m cv_parser.pipeline path/to/cv.pdf
"""
import json
import sys

from .extract import extract_text
from .sections import split_sections
from .entities import (
    detect_language, extract_contact, guess_name, extract_date_ranges,
)
from .skills import extract_skills, group_by_category


def parse_cv(path: str) -> dict:
    """Parse a CV file into a structured JSON-able dict."""
    raw = extract_text(path)
    sections = split_sections(raw)

    header_text = sections.get("header", "") + sections.get("contact", "")
    contact = extract_contact(header_text or raw)

    # Detect language per section (CVs are often mixed FR/EN)
    section_langs = {
        name: detect_language(txt)
        for name, txt in sections.items() if len(txt.strip()) > 30
    }
    langs = [l for l in section_langs.values() if l != "other"]
    doc_lang = max(set(langs), key=langs.count) if langs else "unknown"

    # Skills: prioritize the skills section but scan the whole document,
    # since skills are often mentioned inside experience bullets too.
    skill_list = extract_skills(raw)

    dates = extract_date_ranges(
        sections.get("experience", "") + sections.get("education", "")
    )

    return {
        "file": path,
        "name": guess_name(header_text or raw),
        "contact": contact,
        "document_language": doc_lang,
        "section_languages": section_langs,
        "sections_found": list(sections.keys()),
        "skills": skill_list,
        "skills_by_category": group_by_category(skill_list),
        "date_ranges": dates,
    }


def main():
    if len(sys.argv) < 2:
        print("Usage: python -m cv_parser.pipeline <cv-file> [more files...]")
        sys.exit(1)
    for path in sys.argv[1:]:
        result = parse_cv(path)
        print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
